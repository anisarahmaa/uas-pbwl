

<?php $__env->startSection('content'); ?>
    <div class="container">
<a class="btn btn-danger btn-sm float-end" href="<?php echo e(url('home')); ?>">Kembali</a>
        <h3>Tambah Data Buku</h3>
        <form action="<?php echo e(url('/buku')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label>Kode Buku</label>
                <input type="text" class="form-control" name="buku_kode">
            </div>
            <div class="mb-3">
                <label>Judul Buku</label>
                <input type="text" class="form-control" name="buku_judul">
            </div>
            <div class="mb-3">
                <label>Terbit Buku</label>
                <input type="text" class="form-control" name="buku_terbit">
            </div>
            <div class="mb-3">
                <input type="submit" value="SIMPAN">
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-uas-am\resources\views/buku/create.blade.php ENDPATH**/ ?>